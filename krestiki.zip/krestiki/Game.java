package krestiki;
import java.util.Scanner;
public class Game {

    Field gameField = new Field();
    Scanner scan = new Scanner(System.in);
    char whoMakeTurn;
    boolean gameOver = false;

    void setupNewGame() {
        System.out.println("Начало игры");
        this.gameField = new Field();
        this.gameField.initField();
        this.gameField.printField();
    }

    void play() {
        this.setupNewGame();
        System.out.println("Какая фигура играет первым X | 0?");
        char first = this.scan.next().charAt(0);
        if (first == 'X' || first == '0') {
            this.whoMakeTurn = first;
        } else {
            System.out.println("Ты ошибся. Тебе нужно ввести X или 0 (Ноль). Была назначина фигура X");
                this.whoMakeTurn = 'X';
            }
            while (!gameOver) {
                turn();
                this.gameOver = this.gameField.isGameOver(whoMakeTurn);
                if (this.gameOver) {
                    System.out.println(this.whoMakeTurn + ", Победил!");
                }

                if (this.whoMakeTurn == 'X') {
                    this.whoMakeTurn = '0';
                } else {
                    this.whoMakeTurn = 'X';
                }
            }
    }
    void turn() {
        System.out.println(this.whoMakeTurn + ", Твой ход");
        System.out.println("Выбери row: ");
        int rowNum = this.scan.nextInt();
        System.out.println("Выбери col: ");
        int colNum = this.scan.nextInt();
        int rowIndex = rowNum - 1;
        int colIndex = colNum - 1;
        if (this.gameField.isPlaceFree(rowIndex, colIndex)) {
            this.gameField.setValue(rowIndex, colIndex, this.whoMakeTurn);
            this.gameField.printField();
        } else {
            System.out.println("Неправильное число(Возможно ячейка занята)");
                turn();
        }
    }
}

