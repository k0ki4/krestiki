package krestiki;
public class Field {
    char[][] field;
    int size = 3;
    int count = 3;
    private Field field1;

    void  initField() {
        this.field = new char[this.size][this.size];
        for (int row = 0; row < this.size; row++) {
            for (int col = 0; col < this.size; col++) {
                this.field[row][col] = ' ';
            }
        }
        System.out.println("Поле сгенерированно");
    }
    void printField() {
        System.out.print("   ");
        for (int i = 1; i <= this.size; i++) {
            System.out.print(i + "   ");
        }
        System.out.println();
        for (int row = 0; row < this.size; row++) {
            System.out.print(row + 1);
            for (int col = 0; col < this.size; col++) {
                System.out.print(" [" + this.field[row][col] + "]");
            }
            System.out.println();
        }
    }
    boolean isPlaceFree(int rowIndex,int colIndex) {
        if (rowIndex < 0 || colIndex < 0 || rowIndex >= this.size || colIndex >= this.size) {
            return false;
        }
        if (this.field[rowIndex][colIndex] == ' ') {
            return true;
        } else {
            return false;
        }

    }
    void  setValue(int rowIndex, int colIndex, char value) {
        this.field[rowIndex][colIndex] = value;
    }
    boolean isGameOver(char value) {
        for (int row = 0; row < this.size; row++) {
            for (int col = 0; col < this.size; col++) {
                if (checkRightDirt(row, col, value)) {
                    return true;
                }
                if (checkDown(row, col, value)) {
                    return true;
                }
                if (checkRightDiagonal(row, col, value)) {
                    return true;
                }
                if (checkLeftDiagonal(row, col, value)) {
                    return true;
                }
            }
        }
        return false;
    }
    boolean checkRightDirt(int row, int col, char player) {
        if (col > this.size - this.count) {
            return false;
        }
        for (int i = col; i < col + this.count; i++) {
            if (this.field[row][i] != player) {
                return false;
            }
        }
        return true;

    }
    boolean checkDown(int row, int col, char player) {
        if (row > this.size - this.count) {
            return false;
        }

        for (int i = row; i < row + this.count; i++) {
            if (this.field[i][col] != player) {
                return false;
            }
        }
        return true;

    }

    boolean checkRightDiagonal(int row, int col, char player) {
        if (row > this.size - this.count) {
            return false;
        }
        if (col > this.size - this.count) {
            return false;
        }


        for (int i = 0; i < this.count; i++) {
            int indexRow = row + i;
            int indexCol = col + i;
            if (this.field[indexRow][indexCol] != player) {
                return false;
            }
        }
        return true;
    }
    boolean checkLeftDiagonal(int row, int col, char player) {
        if (row > this.size - this.count) {
            return false;
        }
        if (col < this.size - 1) {
            return false;
        }


        for (int i = 0; i < this.count; i++) {
            int indexRow = row + i;
            int indexCol = col - i;
            if (this.field[indexRow][indexCol] != player) {
                return false;
            }
        }
        return true;
    }
}

